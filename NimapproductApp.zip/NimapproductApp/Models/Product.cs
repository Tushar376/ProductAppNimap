﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace NimapproductApp.Models
{
    public class Product
    {
        [Key]
        public int ProductId { get; set; }
        [Required]
        public string? ProductName { get; set; }
        [ForeignKey("CategoryId")]
        public int CategoryId { get; set; }
        public string? CategoryName { get; set; }

       
    }
}
