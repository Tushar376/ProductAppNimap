﻿using Microsoft.EntityFrameworkCore;
using System.Diagnostics.Metrics;

namespace NimapproductApp.Models
{
    public class AppDbContext:DbContext
    {
        public AppDbContext(DbContextOptions<AppDbContext> Context) : base(Context)
        {
                
        }

        public DbSet<Product> Products { get; set;}
        public DbSet<Category> Categories { get; set;}
    }
}
