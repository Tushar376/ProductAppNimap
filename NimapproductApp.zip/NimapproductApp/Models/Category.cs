﻿using System.ComponentModel.DataAnnotations;

namespace NimapproductApp.Models
{
   
    public class Category
    {
        [Key]
        public int CategorId { get; set; }
        public string? CategorName { get; set; }
        public List<Product>? Products { get; set; }
    }
}
