﻿using Microsoft.AspNetCore.Mvc;
using NimapproductApp.Models;
using NimapproductApp.Repository;

namespace NimapproductApp.Controllers
{
    public class CategoryController : Controller
    {
        readonly ICategoryRepository _categoryRepository;
        public CategoryController(ICategoryRepository categoryRepository)
        {
            _categoryRepository = categoryRepository;
        }

        [Route("")]
        [HttpGet]
        public ActionResult Index()
        {
            var categories = _categoryRepository.GetAllCategories();
            return View(categories);
        }

        public ActionResult GetAllCategories(int id)
        {
            var category = _categoryRepository.GetCategoryByID(id);
            if (category != null)
            {
                return View(category);
            }
            return NotFound();
        }

        [Route("Category/AddCategory")]
        [HttpGet]
        public ActionResult AddCategory()
        {
            return View();
        }

        [HttpPost]
        public ActionResult AddCategory(Category category)
        {
             _categoryRepository.AddCategory(category);
             return RedirectToAction("Index");
        }

        [Route("Category/GetCategoryByID")]
        [HttpGet]
        public ActionResult GetCategoryByID(int id)
        {
            _categoryRepository.GetCategoryByID(id);
            return View();
        }

        [Route("Category/UpdateCategory")]
        [HttpGet]
        public ActionResult UpdateCategory(int id)
        {
            var product = _categoryRepository.GetCategoryByID(id);
            return View(product);
        }

        [HttpPost]
        public ActionResult UpdateCategory(Category category)
        {
            _categoryRepository.UpdateCategory(category);
            return RedirectToAction("index");
        }


        [Route("Category/DeleteCategory")]
        [HttpGet]
        public ActionResult DeleteCategory(int id)
        {
            _categoryRepository.GetCategoryByID(id);
            return RedirectToAction("index");
        }

        [HttpPost]
        public ActionResult DeleteCategory(Category category)
        {
            int id =category.CategorId;
            _categoryRepository.DeleteCategory(category);
            return RedirectToAction("index");
        }


    }
}
