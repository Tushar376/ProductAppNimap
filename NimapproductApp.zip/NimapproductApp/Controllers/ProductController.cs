﻿using Microsoft.AspNetCore.Mvc;
using NimapproductApp.Models;
using NimapproductApp.Repository;

namespace NimapproductApp.Controllers
{
    public class ProductController : Controller
    {
        readonly IProductRepository _productRepository;
        public ProductController(IProductRepository productRepository)
        {
            _productRepository = productRepository;
        }



        [HttpGet]
        public IActionResult Index()
        {
            List<Product> allProductss = _productRepository.GetAllProducts();
            return View(allProductss);

        }

        [Route("Product/AddProduct")]
        [HttpGet]
        public IActionResult AddProduct()
        {
            return View();
        }

        [HttpPost]
        public IActionResult AddProduct(Product Product)
        { 
                var addProductStatus = _productRepository.AddProduct(Product);
                return RedirectToAction("Index");
        }


        [HttpPost]
        public ActionResult Error()
        {
            string errorMessage = TempData["ErrorMessage"] as string;
            ViewBag.ErrorMessage = errorMessage;

            return View();
        }


        [HttpGet]
        [Route("Product/UpdateProduct")]
        public ActionResult UpdateProduct(int id)
        {
            var Product = _productRepository.GetProductById(id);
            return View(Product);
        }

        [HttpPost]
        public ActionResult UpdateProduct(Product Product)
        {
            _productRepository.UpdateProduct(Product);
            return RedirectToAction("Index");
        }


        [Route("Product/DeleteProduct")]
        [HttpGet]
        public ActionResult DeleteProduct(int id)
        {
            var Product = _productRepository.GetProductById(id);
            return View(Product);
        }

        [HttpPost]
        public ActionResult DeleteProduct(Product Product)
        {
            _productRepository.DeleteProduct(Product.ProductId);
            return RedirectToAction("Index");
        }

    }

}
