﻿using NimapproductApp.Models;

namespace NimapproductApp.Repository
{
    public interface ICategoryRepository
    {
        public List<Category> GetAllCategories();
        public Category GetCategoryByID(int categoryID);
        public void AddCategory(Category category);
        public void UpdateCategory(Category category);
        public void DeleteCategory(int categoryID);
        void DeleteCategory(Category category);
    }
}
