﻿using Microsoft.AspNetCore.Mvc;
using NimapproductApp.Models;
using System.Reflection.Metadata.Ecma335;

namespace NimapproductApp.Repository
{
    public class ProductRepository:IProductRepository
    {
        readonly AppDbContext _appDbContext;
        public ProductRepository(AppDbContext appDbContext)
        {
            _appDbContext = appDbContext;
                
        }

        public bool AddProduct(Product product)
        {
            Product productExist = GetProductByName(product.ProductName);
            if (productExist != null)
            {
                return false;
            }
            else
            {
                _appDbContext.Products.Add(product);
                return _appDbContext.SaveChanges() == 1 ? true : false;
            }

        }

       
        public List<Product> GetAllProducts()
        {
            return _appDbContext.Products.ToList();
        }

        public Product GetProductById(int id)
        {
            var product = _appDbContext.Products.Find(id);
            return product;
        }

        public void UpdateProduct(Product product)
        {

            var Prod = _appDbContext.Products.FirstOrDefault(u => u.ProductId==product.ProductId);
            if (Prod != null)
            {
                _appDbContext.Remove(product);
                _appDbContext.Add(Prod);
                _appDbContext.SaveChanges();
            }
            Console.WriteLine("Category updated: " + product.ProductName);
        }

        private Product GetProductByName(string name)
        {
            return _appDbContext.Products.Where(p => p.ProductName == name).FirstOrDefault();
        }

        public void DeleteProduct(int productId)
        {
            var product = _appDbContext.Products.Find(productId);
            if (product != null)
            {
                _appDbContext.Products.Remove(product);
                _appDbContext.SaveChanges();
                Console.WriteLine("Category deleted: " + product.ProductName);
            }
            else
            {
                Console.WriteLine("Category not found: " + productId);
            }
        }



    }
}
