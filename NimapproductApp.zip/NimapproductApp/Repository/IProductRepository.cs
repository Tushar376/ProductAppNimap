﻿using NimapproductApp.Models;

namespace NimapproductApp.Repository
{
    public interface IProductRepository
    {
        public bool AddProduct(Product product);
        void DeleteProduct(int productId);
        List<Product> GetAllProducts();
       
        Product GetProductById(int id);
        void UpdateProduct(Product product);
    }
}
