﻿using Microsoft.EntityFrameworkCore;
using NimapproductApp.Models;

namespace NimapproductApp.Repository
{
    public class CategoryRepository : ICategoryRepository
    {
        readonly AppDbContext _appDbContext;
        public CategoryRepository(AppDbContext appDbContext)
        {
            _appDbContext = appDbContext ?? throw new ArgumentNullException(nameof(appDbContext));
        }
        public void AddCategory(Category category)
        {
            _appDbContext.Categories.Add(category);
            _appDbContext.SaveChanges();
        }

        public List<Category> GetAllCategories()
        {
            return _appDbContext.Categories.ToList();
        }

        public Category GetCategoryByID(int categoryID)
        {
            return _appDbContext.Categories.Find(categoryID);
        }


        public void UpdateCategory(Category category)
        {
            var cat = _appDbContext.Categories.FirstOrDefault(u => u.CategorId==category.CategorId);
            if (cat != null)
            {
                _appDbContext.Categories.Remove(cat);
                _appDbContext.Categories.Add(cat);
                _appDbContext.SaveChanges();
            }
            Console.WriteLine("Category updated: " + category.CategorName);
        }

        public void DeleteCategory(int categoryID)
        {
            var category = _appDbContext.Categories.Find(categoryID);
            if (category != null)
            {
                _appDbContext.Categories.Remove(category);
                _appDbContext.SaveChanges();
                Console.WriteLine("Category deleted: " + category.CategorName);
            }
            else
            {
                Console.WriteLine("Category not found: " + categoryID);
            }
        }

        public void DeleteCategory(Category category)
        {
            throw new NotImplementedException();
        }
    }
}
